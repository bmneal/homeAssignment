package sample;

public interface Worker
{
   public void hire();
   public void fire();
}
